import pyautogui as pg
import time, os, pandas as pd, logging, logging.handlers
import logging.config, sys


logging.config.fileConfig('./logs/logging2.conf')

logger = logging.getLogger('root')

# criar um logger
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s:%(levelname)s - Function:%(funcName)s - %(message)s')
#Criar stream no terminal
stream = logging.StreamHandler()
stream.setFormatter(formatter)
logger.addHandler(stream)
#criar log em arquivo local
file = logging.FileHandler('rpa_log.log', encoding="utf-8")
file.setFormatter(formatter)
file.setLevel(logging.INFO)
logger.addHandler(file)



def try_locate_image(imagePath, try_count=0, tries=5):
    while try_count >= 0:
        position = pg.locateOnScreen(imagePath, grayscale=True, confidence=0.7)
        time.sleep(1)
        try_count += 1
        print(try_count)
        if try_count >= tries or position is not None:
            break
    try:
        if position is not None:
            print(f"position = {position}")
            return position
        else:
            raise Exception(f'Imagem: "{imagePath}", não localizada')
    except Exception as error:
        print(error)
        pg.screenshot(str("./assets/images/Error_screenshot.png"))
        sys.exit()

os.startfile(r'C:\Program Files\Fakturama2\Fakturama.exe')

valida_fakturama = try_locate_image(r".\assets\images\btn_new_product.PNG", tries=30)






df = pd.read_excel(r"C:\Temp\aula4\challenge.xlsx")
print(df.head())


for i, r in df.iterrows():
    first_name  = str(r["First Name"])
    last_name  = str(r["Last Name"])
    company = str(r["Company Name"])
    role = str(r["Role in Company"])
    address = str(r["Address"])
    email = str(r["Email"])
    phone = str(r["Phone Number"])

    botao = try_locate_image(r'.\assets\images\btn_new_contact.png')
    print(botao)
    pg.click(botao, interval=2)

    label = try_locate_image(r'.\assets\images\label_new_contact.png')
    pg.click(label, interval=2)

    print('Preenchendo Company...')
    pg.press('tab', 2, interval=0.5)
    pg.typewrite(company, 0.2)

    print('Preenchendo first_name ...')
    pg.press('tab', 2, interval=0.5)
    pg.typewrite(first_name, 0.2)

    print('Preenchendo last_name ...')
    pg.press('tab', 1, interval=0.5)
    pg.typewrite(last_name, 0.2)
    
    print('Preenchendo address ...')
    pg.press('tab', 5, interval=0.5)
    pg.typewrite(address, 0.2)

    print('Preenchendo email ...')
    pg.press('tab', 7, interval=0.5)
    pg.typewrite(email, 0.2)

    print('Preenchendo phone ...')
    pg.press('tab', 1, interval=0.5)
    pg.typewrite(phone, 0.2)

    time.sleep(1)
    pg.hotkey('ctrl', 's')
    time.sleep(1)
    pg.hotkey('ctrl', 'w')
    time.sleep(1)





