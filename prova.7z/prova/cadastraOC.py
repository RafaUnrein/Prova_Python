import pyautogui as pg
import time, os, pandas as pd, logging, logging.config, logging.handlers
#import pymsteams




logging.config.fileConfig('./logs/logging2.conf')
logger = logging.getLogger('root')

os.startfile(r'C:\Program Files\Fakturama2\Fakturama.exe')
time.sleep(20)
#myTeamsMessage = pymsteams.connectorcard("<Microsoft Webhook URL>")
#teams =
#teams.text("Texto para mandar")
#teams.send()

for i in range(2):
    botao = pg.locateOnScreen(r'.\assets\images\btn_new_order.png', grayscale=True, confidence=0.7)
    print(botao)
    pg.click(botao, interval=2)


    label = pg.locateOnScreen(r'.\assets\images\label_new_order.png', grayscale=True, confidence=0.7)
    pg.click(label, interval=2)
    time.sleep(1)


    label_new_address = pg.locateOnScreen(r'.\assets\images\btn_new_address.png', grayscale=True, confidence=0.7)
    pg.click(label_new_address, interval=2)
    time.sleep(1)

    select_contact1 = pg.locateOnScreen(r'.\assets\images\label_contato1.png', grayscale=True, confidence=0.7)
    pg.click(select_contact1, interval=2)
    time.sleep(0.5)
    btn_ok = pg.locateOnScreen(r'.\assets\images\btn_ok.png', grayscale=True, confidence=0.7)
    pg.click(btn_ok)
    time.sleep(2)

    select_item_1 = pg.locateOnScreen(r'.\assets\images\btn_add_item.png', grayscale=True, confidence=0.7)
    pg.click(select_item_1, interval=2)
    time.sleep(0.5)

    select_item_1_1 = pg.locateOnScreen(r'.\assets\images\label_item_1.png', grayscale=True, confidence=0.7)
    pg.doubleClick(select_item_1_1)
    time.sleep(1)

    select_item_2 = pg.locateOnScreen(r'.\assets\images\btn_add_item.png', grayscale=True, confidence=0.7)
    pg.doubleClick(select_item_2)
    time.sleep(0.5)

    select_item_2_2 = pg.locateOnScreen(r'.\assets\images\label_item_2.png', grayscale=True, confidence=0.7)
    pg.doubleClick(select_item_2_2)
    time.sleep(1)

    time.sleep(1)
    pg.hotkey('ctrl', 's')
    time.sleep(1)
    pg.hotkey('ctrl', 'w')
    time.sleep(1)
    time.sleep(5)